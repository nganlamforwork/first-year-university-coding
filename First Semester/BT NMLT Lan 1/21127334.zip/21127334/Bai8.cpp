#include <bits/stdc++.h>
using namespace std;

int main()
{
    double v,s,t;
    cout<<"Nhap van toc xe x (km/h): ";
    cin>>v;
    cout<<"Nhap do dai quang duong (km): ";
    cin>>s;
    t=s/v;
    cout<<"Thoi gian di la: "<<t<<" gio";
    return 0;
}
